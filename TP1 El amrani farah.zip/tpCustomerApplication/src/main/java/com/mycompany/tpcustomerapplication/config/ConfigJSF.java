package com.mycompany.tpcustomerapplication.config;

import javax.enterprise.context.ApplicationScoped;
import javax.faces.annotation.FacesConfig;

/**
 *
 * @author grin
 */
@ApplicationScoped
@FacesConfig
public class ConfigJSF {
}
